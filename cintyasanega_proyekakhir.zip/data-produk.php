<?php
session_start();
include 'db.php';
if ($_SESSION['status_login'] != true) {
     echo '<script>window.location="login.php"</script>';
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Data Produk</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel=" preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
     <header>
          <div class="container">
               <h1 class="nav"><a href="dashboard.php">Rengginang Cipta Rasa</a></h1>
               <ul>
                    <li><a href="dashboard.php"><img src="img/icon/index.png" width="30px"></a></li>
                    <li><a href="profil.php"><img src="img/icon/admin.png" width="30px"></a></li>
                    <li><a href="admin-kategori.php"><img src="img/icon/datakat.png" width="30px"></a></li>
                    <li><a href="data-produk.php"><img src="img/icon/produk2.png" width="30px"></a></li>
                    <li><a href="logout.php" onclick="return confirm('Apakah yakin untuk keluar?')"><img src="img/icon/logout.png" width="30px"></a></li>
               </ul>
          </div>
     </header>

     <div class="section">
          <div class="container">
               <h3 style="font-size: 25px;">Data Produk</h3>
               <div class="box">
                    <p><a href="tambah-produk.php"><img src="img/icon/tambah2.png" ; width="40px" style="margin-bottom: 10px;"></a><a href="data-review.php"><img src="img/icon/review.png" ; width="40px" style="float:right;  "></a></p>
                    <table border="1" cellspacing='0' class="table">
                         <thead>
                              <tr>
                                   <th width=60px style="font-size: 20;">No</th>
                                   <th style="font-size: 20;">Kategori</th>
                                   <th style="font-size: 20;">Nama Produk</th>
                                   <th style="font-size: 20;">Gambar</th>
                                   <th style="font-size: 20;">Tanggal</th>
                                   <th style="font-size: 20;">Harga</th>
                                   <th style="font-size: 20;">Status</th>
                                   <th width=180px style="font-size: 20;">Aksi</th>
                              </tr>
                         </thead>
                         <tbody>
                              <?php
                              $no = 1;
                              $produk = mysqli_query($conn, "SELECT * FROM product_tb LEFT JOIN category_tb USING (category_id) ORDER BY product_id DESC");
                              if (mysqli_num_rows($produk) > 0) {
                                   while ($row = mysqli_fetch_array($produk)) {
                              ?>
                                        <tr>
                                             <td style="text-align: center; font-size: 18px;" ><?php echo $no++ ?></td>
                                             <td style="font-size: 18px;"><?php echo $row['category_name'] ?></td>
                                             <td style="font-size: 18px;"><?php echo $row['product_name'] ?></td>
                                             <td style="font-size: 18px;"><img src="produk/<?php echo $row['product_image'] ?>" width="50px"></td>
                                             <td style="font-size: 18px;"><?php echo $row['product_date'] ?></td>
                                             <td style="font-size: 18px;">Rp <?php echo number_format($row['product_price'])  ?></td>
                                             <td style="text-align: center; font-size: 18px;"><?php echo $row['product_status'] ?></td>
                                             <td>
                                                  <!-- mengedit sambil mengirim id kategori tiap kategori hapus juga sama -->
                                                  <a href="preview.php?id=<?php echo $row['product_id'] ?>"><img src="img/icon/preview2.png" ; width="35px" ; style="margin: 0 5px 0 15px;"></a>
                                                  <a href="edit-produk.php?id=<?php echo $row['product_id'] ?>"><img src="img/icon/edit2.png" ; width="35px" ; style="margin-right: 5px;"></a>
                                                  <a href="hapus-produk.php?idp=<?php echo $row['product_id'] ?>" onclick="return confirm('Apakah yakin untuk menghapus produk?')"><img src="img/icon/delete2.png" ; width="35px"></a>
                                             </td>
                                        </tr>

                                   <?php }
                              } else { ?>
                                   <tr>
                                        <td colspan="9">Tidak ada data produk</td>
                                   </tr>
                              <?php } ?>

                         </tbody>
                    </table>
               </div>
          </div>
     </div>


     <footer>
          <div class="container">
               <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
          </div>
     </footer>
</body>

</html>