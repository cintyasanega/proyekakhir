<?php
session_start();
include 'db.php';

$produk = mysqli_query($conn, "SELECT * FROM product_tb WHERE product_id = '" . $_GET['id'] . "'");
$p = mysqli_fetch_object($produk);

if ($_SESSION['status_login'] != true) {
     echo '<script>window.location="login.php"</script>';
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Data Produk</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel=" preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
     <header>
          <div class="container">
               <h1 class="nav"><a href="dashboard.php">Rengginang Cipta Rasa</a></h1>
               <ul>
                    <li><a href="dashboard.php"><img src="img/icon/index.png" width="30px"></a></li>
                    <li><a href="profil.php"><img src="img/icon/admin.png" width="30px"></a></li>
                    <li><a href="admin-kategori.php"><img src="img/icon/datakat.png" width="30px"></a></li>
                    <li><a href="data-produk.php"><img src="img/icon/produk2.png" width="30px"></a></li>
                    <li><a href="logout.php" onclick="return confirm('Apakah yakin untuk keluar?')"><img src="img/icon/logout.png" width="30px"></a></li>
               </ul>
          </div>
     </header>

     <div class="section">
          <div class="container">
               <h3>Detail Produk</h3>
               <div class="box">
                    <div class="col-2">
                         <img src="produk/<?php echo $p->product_image ?>">
                    </div>
                    <div class="col-2">
                         <h3><?php echo $p->product_name ?></h3>
                         <p>Deskripsi: <br>
                              <?php echo $p->product_description ?></p>
                         <h5><?php echo $p->product_date ?></h5>
                         <h4>Rp <?php echo number_format($p->product_price) ?></h4>
                    </div>
                    <div class="review">
                         <h3 style="text-align: center;">Tulis Ulasan Produk</h3>
                         <form action="" method="POST">
                              <input type="text" name="username" placeholder="Tulis nama" class="login-1" required>
                              <textarea class="login-1" name="review_text" placeholder="Tulis review disini..."></textarea>
                              <select class="login-1" name="rating">
                                   <option value="1">1 Bintang</option>
                                   <option value="2">2 Bintang</option>
                                   <option value="3">3 Bintang</option>
                                   <option value="4">4 Bintang</option>
                                   <option value="5">5 Bintang</option>
                              </select><br>
                              <input type="submit" value="Kirim Ulasan" class="btn-login">
                         </form>

                         <?php
                         if (isset($_POST['submit'])) {
                              $username = $_POST['username'];
                              $review = $_POST['review'];
                              $rating = $_POST['rating'];

                              $insert = mysqli_query($conn, "INSERT INTO reviews (id, username, review_text, rating, data_create) VALUES (null, '" . $username . "', '" . $review . "', '" . $rating . "', null)");
                              if ($insert) {
                                   echo '<script>alert"Tambah data berhasil"</script>';
                              } else {
                                   echo 'gagal' . mysqli_error($conn);
                              }
                         }
                         ?>

                    </div>
               </div>
          </div>
     </div>
     </div>




     <footer>
          <div class="container">
               <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
          </div>
     </footer>
</body>

</html>