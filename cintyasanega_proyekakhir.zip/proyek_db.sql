-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2023 at 07:32 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proyek_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE `admin_tb` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(1, 'Cintya Sanega Akmalia', 'cityasn_', 'ddc0b49ac29e15533013f7e1ac64f615', '083869837730', 'akmaliasanegacintya@gmail.com', 'PGA No.13A, Lengkong, Bojongsoang'),
(2, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `category_tb`
--

CREATE TABLE `category_tb` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_tb`
--

INSERT INTO `category_tb` (`category_id`, `category_name`) VALUES
(5, 'Rengginang'),
(6, 'Nilayoo Frozen'),
(7, 'Wajit'),
(8, 'Angle'),
(9, 'Dodol Kacang');

-- --------------------------------------------------------

--
-- Table structure for table `product_tb`
--

CREATE TABLE `product_tb` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_date` date DEFAULT NULL,
  `product_description` text NOT NULL,
  `product_price` text NOT NULL,
  `product_status` tinyint(1) NOT NULL,
  `data_create` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_tb`
--

INSERT INTO `product_tb` (`product_id`, `category_id`, `product_name`, `product_image`, `product_date`, `product_description`, `product_price`, `product_status`, `data_create`) VALUES
(38, 5, 'Rengginang Terasi Merah Cipta Rasa', 'produk1694456886.jpg', '2022-10-13', 'Rengginang adalah sejenis kerupuk tebal yang terbuat dari beras ketan yang dibentuk bulat dan dikeringkan dengan cara dijemur di bawah panas matahari, lalu digoreng panas dalam minyak goreng.\r\n\r\n\r\nKomposisi :\r\n\r\nBeras Ketan\r\nTerasi Bakar\r\nAir \r\nBawang putih \r\nKetumbar \r\nGaram\r\n\r\n \r\n\r\nUkuran :\r\n\r\nDiameter : 6cm (akan melebar jika sudah digoreng)\r\nBerat       : 500 gram/pack\r\nIsi            : 24/pack\r\n\r\n \r\n\r\nCara Penggorengan :\r\n1. Panaskan minyak di dalam wajan\r\n2. Setelah minyak panas, goreng rengginang satu per satu hingga matang\r\n3. Ulangi tahap ke -2 untuk renginang berikutnya\r\n4. Angkat dan tiriskan\r\n\r\n \r\n\r\n*Saran : Agar rengginang jauh lebih mengembang lebih baik dijemur 1-3 jam sebelum di goreng\r\n\r\n\r\n\r\n\r\nTanggal Pengiriman    : 15-10-2023\r\nTanggal Kadaluwarsa : 13-10-2023', '25000', 1, '2023-09-11 18:28:06'),
(39, 5, 'Rengginang Terasi Merah Cipta Rasa', 'produk1694457143.jpg', '2022-08-22', 'Rengginang adalah sejenis kerupuk tebal yang terbuat dari beras ketan yang dibentuk bulat dan dikeringkan dengan cara dijemur di bawah panas matahari, lalu digoreng panas dalam minyak goreng.\r\n\r\n\r\nKomposisi :\r\n\r\nBeras Ketan\r\nTerasi Bakar\r\nAir \r\nBawang putih \r\nKetumbar \r\nGaram\r\n\r\n \r\n\r\nUkuran :\r\n\r\nDiameter : 6cm (akan melebar jika sudah digoreng)\r\nBerat       : 500 gram/pack\r\nIsi            : 24/pack\r\n\r\n \r\n\r\nCara Penggorengan :\r\n1. Panaskan minyak di dalam wajan\r\n2. Setelah minyak panas, goreng rengginang satu per satu hingga matang\r\n3. Ulangi tahap ke -2 untuk renginang berikutnya\r\n4. Angkat dan tiriskan\r\n\r\n \r\n\r\n*Saran : Agar rengginang jauh lebih mengembang lebih baik dijemur 1-3 jam sebelum di goreng\r\n\r\n\r\n\r\n\r\nTanggal Pengiriman    : 25-08-2023\r\nTanggal Kadaluwarsa : 22-08-2023', '25000', 1, '2023-09-11 18:32:23'),
(40, 5, 'Rengginang Terasi Merah Cipta Rasa', 'produk1694457172.png', '2022-09-21', 'Rengginang adalah sejenis kerupuk tebal yang terbuat dari beras ketan yang dibentuk bulat dan dikeringkan dengan cara dijemur di bawah panas matahari, lalu digoreng panas dalam minyak goreng.\r\n\r\n\r\nKomposisi :\r\n\r\nBeras Ketan\r\nTerasi Bakar\r\nAir \r\nBawang putih \r\nKetumbar \r\nGaram\r\n\r\n \r\n\r\nUkuran :\r\n\r\nDiameter : 6cm (akan melebar jika sudah digoreng)\r\nBerat       : 500 gram/pack\r\nIsi            : 24/pack\r\n\r\n \r\n\r\nCara Penggorengan :\r\n1. Panaskan minyak di dalam wajan\r\n2. Setelah minyak panas, goreng rengginang satu per satu hingga matang\r\n3. Ulangi tahap ke -2 untuk renginang berikutnya\r\n4. Angkat dan tiriskan\r\n\r\n \r\n\r\n*Saran : Agar rengginang jauh lebih mengembang lebih baik dijemur 1-3 jam sebelum di goreng\r\n\r\n\r\n\r\n\r\nTanggal Pengiriman    : 24-09-2023\r\nTanggal Kadaluwarsa : 21-09-2023', '25000', 1, '2023-09-11 18:32:52'),
(41, 5, 'Rengginang Original Cipta Rasa', 'produk1694457206.jpg', '2022-07-22', 'Rengginang adalah sejenis kerupuk tebal yang terbuat dari beras ketan yang dibentuk bulat dan dikeringkan dengan cara dijemur di bawah panas matahari, lalu digoreng panas dalam minyak goreng.', '25000', 1, '2023-09-11 18:33:26'),
(42, 9, 'Dodol Kacang Medal Sari', 'produk1694457250.png', '2022-09-09', 'dodolllll', '17000', 1, '2023-09-11 18:34:10'),
(43, 7, 'Wajit Medal Rasa', 'produk1694457283.jpg', '2022-10-09', 'wajittt', '20000', 1, '2023-09-11 18:34:43'),
(44, 6, 'Nilayoo Frozen', 'produk1694457326.png', '2022-10-10', 'ikan nila marinasi ', '30000', 1, '2023-09-11 18:35:26');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `review_text` text NOT NULL,
  `rating` int(11) NOT NULL,
  `data_create` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `username`, `review_text`, `rating`, `data_create`) VALUES
(5, 'CINTYA', 'nyoba bikin review', 5, '2023-09-13 15:48:10'),
(7, 'cintyasanega', 'blablabla', 5, '2023-09-13 15:49:39'),
(11, 'nyoba', 'nyoba review aja si', 3, '2023-09-14 04:07:39'),
(12, 'cintya', 'apakah ini enak?/', 4, '2023-09-14 04:12:15'),
(13, 'nyobaa', 'apa aja deh yaa', 1, '2023-09-14 04:12:52'),
(14, 'siapa', 'apa', 1, '2023-09-14 04:13:07'),
(15, 'siapa', 'apakah enak?', 5, '2023-09-14 04:13:46'),
(16, 'cintya', 'review', 4, '2023-09-14 04:32:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tb`
--
ALTER TABLE `admin_tb`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category_tb`
--
ALTER TABLE `category_tb`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tb`
--
ALTER TABLE `admin_tb`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category_tb`
--
ALTER TABLE `category_tb`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_tb`
--
ALTER TABLE `product_tb`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
