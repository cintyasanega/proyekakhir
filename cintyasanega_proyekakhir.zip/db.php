<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$dbname = 'proyek_db';

$conn = mysqli_connect($hostname, $username, $password, $dbname) or die('Tidak terhubung ke database');
