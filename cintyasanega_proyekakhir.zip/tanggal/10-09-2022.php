<?php
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Tambah Kategori</title>
 <link rel="stylesheet" href="../css/styles.css">
 <link rel="stylesheet" href="../css/style.css">
 <link rel=" preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
 <div class="container">
  <h1 style="margin: 10px 0;"> RENGGINANG CIPTA RASA</h1>
  <ul>
   <li><a href="../index.php" style="font-weight: bolder; float:right; color:red">Dashboard</a></li>
  </ul>
  <p class="">
   Rengginang yang berasal dari Kampung Cikakak, Desa Batulayang, Bandung Barat. Penjualan dilakukan pada bulan September s.d. Oktober. Rengginang yang memiliki vaiasi rasa terasi merah. Penjualan dilakukan dengan menggunakan metode Pre-Order pada E-Commerce Shopee, Google Form, dan Penjualan Langsung. </p>
 </div>
 </div>
 <section class="services" id="services">
  <h2>Our Services</h2>
  <ul class="cards">
   <li class="card">
    <img src="../img/buat.png" alt="img">
    <h3>Pembuatan</h3>
    <p>Dilakukan selama 2 hari saat cuaca terik dan 3 hari saat cuaca cukup terik</p>
    <h4>10 September 2022 - 13 September 2022</h4>
   </li>
   <li class="card">
    <img src="../img/kemasan.jpg" alt="img">
    <h3>Pengemasan</h3>
    <p>Berisi 24 rengginang mentah dengan kemasan kedap udara</p>
    <h4>14 September 2022</h4>
   </li>
   <li class="card">
    <img src="../img/rengginang.jpg" alt="img">
    <h3>Kedaluwarsa</h3>
    <p>Tahan selama 1 tahun dengan kondisi kemasan terbebas dari udara luar</p>
    <h4>13 September 2023</h4>
   </li>
  </ul>

 </section>
 <section class="home" id="home">
  <div class="max-width">
   <div class="home-content">
    <div class="text-1">Video Pelaksanaan </div>
    <div class="text-2">P2MD DPM KEMA FIT TEL-U 2022</div>
    <a href="https://youtu.be/MCz6bqDcg7o?si=x5Liq54_4L0nA-MF">Lihat Video</a>
   </div>
  </div>
 </section>

 <div class="container-1">
  <div class="rating-wrap">
   <h2>Star Rating</h2>
   <div class="center">
    <fieldset class="rating">
     <input type="radio" id="star5" name="rating" value="5" /><label for="star5" class="full" title="Awesome"></label>
     <input type="radio" id="star4.5" name="rating" value="4.5" /><label for="star4.5" class="half"></label>
     <input type="radio" id="star4" name="rating" value="4" /><label for="star4" class="full"></label>
     <input type="radio" id="star3.5" name="rating" value="3.5" /><label for="star3.5" class="half"></label>
     <input type="radio" id="star3" name="rating" value="3" /><label for="star3" class="full"></label>
     <input type="radio" id="star2.5" name="rating" value="2.5" /><label for="star2.5" class="half"></label>
     <input type="radio" id="star2" name="rating" value="2" /><label for="star2" class="full"></label>
     <input type="radio" id="star1.5" name="rating" value="1.5" /><label for="star1.5" class="half"></label>
     <input type="radio" id="star1" name="rating" value="1" /><label for="star1" class="full"></label>
     <input type="radio" id="star0.5" name="rating" value="0.5" /><label for="star0.5" class="half"></label>
    </fieldset>
   </div>

   <h4 id="rating-value"></h4>
  </div>
 </div>

 <script src="../star-ratings.js"></script>
</body>

</html>