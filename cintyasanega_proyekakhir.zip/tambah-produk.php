<?php
session_start();
include 'db.php';
if ($_SESSION['status_login'] != true) {
     echo '<script>window.location="login.php"</script>';
}
// $produk = mysqli_query($conn, "SELECT * FROM product_tb WHERE product_id = '" . $_GET['id'] . "'");
// $p = mysqli_fetch_object($produk);
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Tambah Produk</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <script src="https://cdn.ckeditor.com/4.23.0-lts/standard/ckeditor.js"></script>
</head>

<body>
     <header>
          <div class="container">
               <h1><a href="dashboard.php">Rengginang Cipta Rasa</a></h1>
               <ul>
                    <li><a href="dashboard.php"><img src="img/icon/index.png" width="30px"></a></li>
                    <li><a href="profil.php"><img src="img/icon/admin.png" width="30px"></a></li>
                    <li><a href="admin-kategori.php"><img src="img/icon/datakat.png" width="30px"></a></li>
                    <li><a href="data-produk.php"><img src="img/icon/produk2.png" width="30px"></a></li>
                    <li><a href="logout.php" onclick="return confirm('Apakah yakin untuk keluar?')"><img src="img/icon/logout.png" width="30px"></a></li>
               </ul>
          </div>
     </header>

     <div class="section">
          <div class="container">
               <h3>Tambah Data Produk</h3>
               <div class="box">
                    <form action="" method="POST" enctype="multipart/form-data">

                         <select name="kategori" class="login-1" style="font-size: 14px;" required>
                              <option value="">--Pilih Kategori--</option>
                              <?php
                              $kategori = mysqli_query($conn, "SELECT * FROM category_tb ORDER BY category_id DESC");
                              while ($r = mysqli_fetch_array($kategori)) { ?>
                                   <option value="<?php echo $r['category_id'] ?>"><?php echo $r['category_name'] ?></option>
                              <?php } ?>
                         </select>

                         <select name="nama" class="login-1" style="font-size: 14px;" required>
                              <option value="" >--Pilih Produk--</option>
                              <option value="Rengginang Terasi Merah Cipta Rasa">Rengginang Terasi Merah Cipta Rasa</option>
                              <option value="Rengginang Original Cipta Rasa">Rengginang Original Cipta Rasa</option>
                              <option value="Rengginang Ketan Hitam Cipta Rasa">Rengginang Ketan Hitam Cipta Rasa</option>
                              <option value="Wajit Medal Rasa">Wajit Medal Rasa</option>
                              <option value="Angle Medal Sari">Angle Medal Sari</option>
                              <option value="Nilayoo Frozen">Nilayoo Frozen</option>
                              <option value="Dodol Kacang Medal Sari">Dodol Kacang Medal Sari</option>
                         </select>

                         <input type="file" name="gambar" class="login-1" style="font-size: 14px;" required>

                         <input type="date" class="login-1" name="tanggal" placeholder="Tanggal Pembuatan" style="font-size: 14px;" required>

                         <input type="text" class="login-1" name="harga" placeholder="Harga" style="font-size: 14px;" required>

                         <textarea class="login-1" id="deskripsi" name="deskripsi" placeholder="Deskripsi" style="font-size: 14px;"></textarea>

                         <select class="login-1" name="status">
                              <option value="">--Pilih Status--</option>
                              <option value="1">Aktif</option>
                              <option value="0">Tidak Aktif</option>
                         </select>

                         <input type="submit" name="submit" value="Submit" class="btn-login">
                    </form>

                    <?php
                    if (isset($_POST['submit'])) {
                         // print_r($_FILES['gambar']); buat cek isi gambar yang akan dipilih buat ditampilin di webnya
                         // menampung inputan form
                         $kategori      = $_POST['kategori'];
                         $nama          = $_POST['nama'];
                         $gambar        = $_POST['gambar'];
                         $tanggal       = $_POST['tanggal'];
                         $harga         = $_POST['harga'];
                         $deskripsi     = $_POST['deskripsi'];
                         $status        = $_POST['status'];

                         // menampung data yang diupload
                         $filename = $_FILES['gambar']['name'];
                         $tmp_name = $_FILES['gambar']['tmp_name'];
                         // untuk membuat string menjadi array sesuai tanda tertentu disini pake .
                         $type_file = explode('.', $filename);
                         $type_save = $type_file[1];

                         // file yang akan masuk ke database diteruskan pada move_uploaded_file
                         $newname = 'produk' . time() . '.' . $type_save;
                         // format data yang dibolehin upload
                         $type_bole = array('jpg', 'jpeg', 'png');

                         // validasi format file inputnya
                         if (!in_array($type_save, $type_bole)) {
                              // file yang dimasukan tidak dibolehin
                              echo '<script>alert("Ubah gambar, format file tidak sesuai")</script>';
                         } else {
                              //  format boleh dan diteruskan masuk ke database
                              move_uploaded_file($tmp_name, './produk/' . $newname);
                              $insert = mysqli_query($conn, "INSERT INTO product_tb 
                              (product_id, 
                              category_id, 
                              product_name, 
                              product_image, 
                              product_date, 
                              product_price, 
                              product_description, 
                              product_status,
                              data_create) VALUES 
                              (null, 
                              '" . $kategori . "', 
                              '" . $nama . "',  
                              '" . $newname . "', 
                              '" . $tanggal . "', 
                              '" . $harga . "',
                              '" . $deskripsi . "', 
                              '" . $status . "', 
                              null)");

                              if ($insert) {
                                   echo '<script>alert"Tambah produk berhasil"</script>';
                                   echo '<script>window.location="data-produk.php"</script>';
                              } else {
                                   echo 'gagal ' . mysqli_error($conn);
                              }
                         }

                         // proses up dan masukin inputan ke db
                    }
                    ?>
               </div>


          </div>
     </div>


     <footer>
          <div class="container">
               <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
          </div>
     </footer>

     <script>
          CKEDITOR.replace('deskripsi');
     </script>
</body>

</html>