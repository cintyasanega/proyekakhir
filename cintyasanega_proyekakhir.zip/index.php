<?php
error_reporting(0);
include 'db.php';

$review = mysqli_query($conn, "SELECT * FROM reviews LIMIT 5" );
$r = mysqli_fetch_object($review);

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rengginang Cipta Rasa</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel=" preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
  <header>
    <div class="container">
      <h1><a href="index.php">Cipta Rasa</a></h1>
      <ul>
        <li><a href="produk.php"><img src="img/icon/produk2.png" width="35px"></a></li>
        <li><a href="contact.php"><img src="img/icon/contact2.png" width="35px" style="margin-left: 10px;"></a></li>
      </ul>
    </div>
  </header>

  <div class="search">
    <div class="container">
      <form action="produk.php">
        <input type="text" name="search" placeholder="Cari Produk">
        <input type="submit" name="cari" value="Cari Produk" class="btn-login">
      </form>
    </div>

    <!-- kategori -->
    <div class="section">
      <div class="container">
        <h3>Kategori</h3>
        <div class="box">
          <?php
          $kategori = mysqli_query($conn, "SELECT * FROM category_tb ORDER BY category_id DESC");
          if (mysqli_num_rows($kategori) > 0) {
            while ($k = mysqli_fetch_array($kategori)) {
          ?>
              <a href="produk.php?kat=<?php echo $k['category_id'] ?>">
                <div class="col-5">
                  <img src="img/icon/produk.png" width="25px">
                  <p><?php echo $k['category_name'] ?></p>
                </div>
              </a>
            <?php }
          } else { ?>
            <p>Kategori kosong</p>
          <?php } ?>
        </div>
      </div>
    </div>

  </div>

  <!-- produk baru -->
  <div class="section">
    <div class="container">
      <h3>Produk</h3>
      <div class="box">
        <?php
        $produk = mysqli_query($conn, "SELECT * FROM product_tb WHERE product_status = 1 ORDER BY product_id DESC LIMIT 4");
        if (mysqli_num_rows($produk) > 0) {
          while ($p = mysqli_fetch_array($produk)) {
        ?>
            <a href="deskripsi.php?id=<?php echo $p['product_id'] ?>">
              <div class="col-4">
                <img src="produk/<?php echo $p['product_image'] ?>">
                <p class="nama"><?php echo $p['product_name'] ?></p>
                <p class="tanggal"><?php echo $p['product_date'] ?></p>
                <p class="harga">Rp <?php echo number_format($p['product_price']) ?></p>
              </div>
            <?php }
        } else { ?>
            <p>Produk Tidak Ada</p>
          <?php } ?>
      </div>
    </div>
  </div>
  <div class="section">
  <div class="container">
   <h3>Review</h3>
   <div class="box">
    <div class="col-2">
      <?php
      if ($r > 0) {
       while  ($row = mysqli_fetch_array($review)) {
        echo "<p><strong>Nama Pengguna:</strong> " . $row["username"] . "</p>";
        echo "<p><strong>Ulasan:</strong> <br>"  . $row["review_text"] . "</p>";
        echo "<p><strong>Peringkat:</strong> <br>";
          $rating = $row["rating"];
          for ($i = 1; $i <= 5; $i++) {
              if ($i <= $rating) {
                  echo '<img src="img/icon/bintang.png" alt="' . $i . ' bintang" style="width: 50px;">';
              } else {
                  echo '<img src="img/icon/nobintang.png" alt="0 bintang" style="width: 50px;">';
              }
          }
          echo "<hr>";
         }
        } else {
         echo "<p>Belum ada ulasan.</p>";
        }
        ?>
    </div>
   </div>
  </div>
<br><br><br>

    <div class="footer">
      <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
    </div>


</body>

</html>