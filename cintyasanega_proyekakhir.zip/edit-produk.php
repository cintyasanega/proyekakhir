<?php
session_start();
include 'db.php';
if ($_SESSION['status_login'] != true) {
     echo '<script>window.location="login.php"</script>';
}
$produk = mysqli_query($conn, "SELECT * FROM product_tb WHERE product_id = '" . $_GET['id'] . "'");
if (mysqli_num_rows($produk) == 0) {
     echo '<script>window.location="data_produk.php"</script>';
}
$p = mysqli_fetch_object($produk);
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Edit Data Produk</title>
     <link rel="stylesheet" href="css/style.css">
     <link href="<link rel=" preconnect href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
     <header>
          <div class="container">
               <h1><a href="dashboard.php">Rengginang Cipta Rasa</a></h1>
               <ul>
                    <li><a href="dashboard.php"><img src="img/icon/index.png" width="30px"></a></li>
                    <li><a href="profil.php"><img src="img/icon/admin.png" width="30px"></a></li>
                    <li><a href="admin-kategori.php"><img src="img/icon/datakat.png" width="30px"></a></li>
                    <li><a href="data-produk.php"><img src="img/icon/produk2.png" width="30px"></a></li>
                    <li><a href="logout.php" onclick="return confirm('Apakah yakin untuk keluar?')"><img src="img/icon/logout.png" width="30px"></a></li>
               </ul>
          </div>
     </header>

     <div class="section">
          <div class="container">
               <h3>Edit Data Produk</h3>
               <div class="box">
                    <form action="" method="POST" enctype="multipart/form-data">
                         <select class="login-1" name="kategori" required>
                              <option value="">--Pilih Kategori--</option>
                              <?php
                              $kategori = mysqli_query($conn, "SELECT * FROM category_tb ORDER BY category_id DESC");
                              while ($r = mysqli_fetch_array($kategori)) {
                              ?>

                                   <option value="<?php echo $r['category_id'] ?>" <?php echo ($r['category_id'] == $p->category_id) ? 'selected' : ''; ?>><?php echo $r['category_name'] ?></option>
                              <?php } ?>
                         </select>
                         <select name="nama" class="login-1" required>
                              <option value="">--Pilih Produk--</option>
                              <option value="Rengginang Terasi Merah Cipta Rasa" <?php echo ($p->product_name == "Rengginang Terasi Merah Cipta Rasa") ? 'selected' : ''; ?>>Rengginang Terasi Merah Cipta Rasa</option>
                              <option value="Rengginang Original Cipta Rasa" <?php echo ($p->product_name == "Rengginang Original Cipta Rasa") ? 'selected' : ''; ?>>Rengginang Original Cipta Rasa</option>
                              <option value="Rengginang Ketan Hitam Cipta Rasa" <?php echo ($p->product_name == "Rengginang Ketan Hitam Cipta Rasa") ? 'selected' : ''; ?>>Rengginang Ketan Hitam Cipta Rasa</option>
                              <option value="Wajit Medal Rasa" <?php echo ($p->product_name == "Wajit Medal Rasa") ? 'selected' : ''; ?>>Wajit Medal Rasa</option>
                              <option value="Angle Medal Sari" <?php echo ($p->product_name == "Angle Medal Sari") ? 'selected' : ''; ?>>Angle Medal Sari</option>
                              <option value="Nilayoo Frozen" <?php echo ($p->product_name == "Nilayoo Frozen") ? 'selected' : ''; ?>>Nilayoo Frozen</option>
                         </select>
                         <input type="date" name="tanggal" class="login-1" placeholder="Tanggal Pembuatan"  value="<?php echo $p->product_date ?>" required>
                         <input type="text" name="harga" class="login-1" placeholder="Harga"  value="<?php echo $p->product_price ?>" required>
                         <img src="produk/<?php echo $p->product_image ?>" width="100px">
                         <input type="hidden" name="foto" value="<?php echo $p->product_image ?>">
                         <input type="file" name="gambar" class="login-1">
                         <textarea class="login-1" name="deskripsi" placeholder="Deskripsi" cols="80" id="editor1" name="editor1" rows="10" ><?php echo $p->product_description ?></textarea>
                         <select name="status" class="login-1">
                              <option value="">--Pilih--</option>
                              <option value="1" <?php echo ($p->product_status == 1) ? 'selected' : ''; ?>>Aktif</option>
                              <option value="0" <?php echo ($p->product_status == 0) ? 'selected' : ''; ?>>Tidak Aktif</option>
                         </select>
                         <input type="submit" name="submit" value="Submit" class="btn-login">
                    </form>

                    <?php
                    if (isset($_POST['submit'])) {

                         // data inputan form 
                         $kategori  = $_POST['kategori'];
                         $nama      = $_POST['nama'];
                         $harga     = $_POST['harga'];
                         $tanggal   = $_POST['tanggal'];
                         $deskripsi = $_POST['deskripsi'];
                         $status    = $_POST['status'];
                         $foto      = $_POST['foto'];

                         // data gambar baru
                         $filename = $_FILES['gambar']['name'];
                         $tmp_name = $_FILES['gambar']['tmp_name'];

                         // jika admin ganti gambar 

                         if ($filename != '') {

                              $type_file = explode('.', $filename);
                              $type_save = $type_file[1];

                              $newname = 'produk' . time() . $type_save;
                              // format data yang dibolehin upload
                              $type_bole = array('jpg', 'jpeg', 'png');

                              // validasi format file
                              if (!in_array($type_save, $type_bole)) {
                                   // jika format ga sesuai type yg dibolehin
                                   echo '<script>alert("Format tidak diizinkan")</script>';
                              } else {
                                   unlink('./produk/' . $foto);
                                   move_uploaded_file($tmp_name, './produk/' . $newname);
                                   $nama_gambar = $newname;
                              }
                         } else {
                              // jika admin tidak ubah gambar
                              $nama_gambar = $foto;
                         }
                         // query update data produk
                         $update = mysqli_query($conn, "UPDATE product_tb SET 
     category_id = '.$kategori.', 
     product_name = '" . $nama . "', 
     product_description = '" . $deskripsi . "', 
     product_price = '" . $harga . "', 
     product_image = '" . $nama_gambar . "', 
     product_status = '" . $status . "' 
     WHERE product_id = '" . $p->product_id . "'");

                         // kondisi saat berhasil tidaknya update
                         if ($update) {
                              echo '<script>alert("Berhasil mengedit data produk")</script>';
                              echo '<script>window.location="data-produk.php"</script>';
                         } else {
                              echo 'gagal' . mysqli_error($conn);
                         }
                    }
                    ?>
               </div>
          </div>
     </div>
     <footer>
          <div class="container">
               <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
          </div>
     </footer>
</body>

</html>