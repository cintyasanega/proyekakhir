<?php
error_reporting(0);
include 'db.php';

$produk = mysqli_query($conn, "SELECT * FROM product_tb WHERE product_id = '" . $_GET['id'] . "'");
$p = mysqli_fetch_object($produk);



// Fungsi untuk menyimpan ulasan ke database
function simpan_ulasan($conn, $username, $review_text, $rating)
{
  $sql = "INSERT INTO reviews (username, review_text, rating) VALUES ('$username', '$review_text', '$rating')";

  if ($conn->query($sql) === TRUE) {
    return true;
  } else {
    return false;
  }
}

// Fungsi untuk menampilkan ulasan dari database
function tampilkan_ulasan($conn)
{
  $sql = "SELECT * FROM reviews";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    echo "<h2>Ulasan Pengguna</h2>";
    while ($row = $result->fetch_assoc()) {
      echo "<p><strong>Nama Pengguna:</strong> " . $row["username"] . "</p>";
      echo "<p><strong>Ulasan:</strong> " . $row["review_text"] . "</p>";
      echo "<p><strong>Peringkat:</strong> " . $row["rating"] . " bintang</p>";
      echo "<hr>";
    }
  } else {
    echo "<p>Belum ada ulasan.</p>";
  }
}

// Main code
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST['username'];
  $review_text = $_POST['review_text'];
  $rating = $_POST['rating'];

  if (simpan_ulasan($conn, $username, $review_text, $rating)) {
    echo 
    '<script>window.location="index.php"</script>';
  } else {
    echo "<p>Gagal menyimpan ulasan.</p>";
  }

  $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detail Produk</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel=" preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
  <header>
    <div class="container">
      <h1><a href="index.php">Cipta Rasa</a></h1>
      <ul>
        <li><a href="index.php"><img src="img/icon/index.png" width="35px" ></a></li>
        <li><a href="produk.php"><img src="img/icon/produk2.png" width="35px" style="margin-left: 10px;"></a></li>
        <li><a href="contact.php"><img src="img/icon/contact2.png" width="35px" style="margin-left: 10px;"></a></li>
      </ul>
    </div>
  </header>

  <div class="section">
    <div class="container">
      <h3>Detail Produk</h3>
      <div class="box">
        <div class="col-2">
          <img src="produk/<?php echo $p->product_image ?>">
        </div>
        <div class="col-2">
          <h3><?php echo $p->product_name ?></h3>

          <p>Deskripsi: <br>
            <?php echo $p->product_description ?></p>
          <h5><?php echo $p->product_date ?></h5>
          <h4>Rp <?php echo number_format($p->product_price) ?></h4>
        </div>

        <div style="margin-top: 50px;" class="review">
          <h3 style="text-align: center;">Tulis Ulasan Produk</h3>
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <input type="text" name="username" placeholder="Tulis nama" class="login-1" required>
            <textarea class="login-1" name="review_text" placeholder="Tulis review disini..."></textarea>
            <select class="login-1" name="rating">
              <option value="1">1 Bintang</option>
              <option value="2">2 Bintang</option>
              <option value="3">3 Bintang</option>
              <option value="4">4 Bintang</option>
              <option value="5">5 Bintang</option>
            </select><br>
            <input type="submit" value="Kirim Ulasan" class="btn-login">
          </form>

        </div>
      </div>


      <!-- <div class="review">
            <h1 class="mt-5 mb-5">Rate Our Product</h1>
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-sm-4 text-center">
                    <h1 class="text-warning mt-4 mb-4">
                      <b><span id="average_rating">0.0</span> / 5</b>
                    </h1>
                    <div class="mb-3">
                      <i class="fas fa-star star-light mr-1 main_star"></i>
                      <i class="fas fa-star star-light mr-1 main_star"></i>
                      <i class="fas fa-star star-light mr-1 main_star"></i>
                      <i class="fas fa-star star-light mr-1 main_star"></i>
                      <i class="fas fa-star star-light mr-1 main_star"></i>
                    </div>
                    <h3><span id="total_review">0</span> Review</h3>
                  </div>
                  <div class="col-sm-4">
                    <p>
                    <div class="progress-label-left"><b>5</b> <i class="fas fa-star text-warning"></i></div>

                    <div class="progress-label-right">(<span id="total_five_star_review">0</span>)</div>
                    <div class="progress">
                      <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="five_star_progress"></div>
                    </div>
                    </p>
                    <p>
                    <div class="progress-label-left"><b>4</b> <i class="fas fa-star text-warning"></i></div>

                    <div class="progress-label-right">(<span id="total_four_star_review">0</span>)</div>
                    <div class="progress">
                      <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="four_star_progress"></div>
                    </div>
                    </p>
                    <p>
                    <div class="progress-label-left"><b>3</b> <i class="fas fa-star text-warning"></i></div>

                    <div class="progress-label-right">(<span id="total_three_star_review">0</span>)</div>
                    <div class="progress">
                      <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="three_star_progress"></div>
                    </div>
                    </p>
                    <p>
                    <div class="progress-label-left"><b>2</b> <i class="fas fa-star text-warning"></i></div>

                    <div class="progress-label-right">(<span id="total_two_star_review">0</span>)</div>
                    <div class="progress">
                      <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="two_star_progress"></div>
                    </div>
                    </p>
                    <p>
                    <div class="progress-label-left"><b>1</b> <i class="fas fa-star text-warning"></i></div>

                    <div class="progress-label-right">(<span id="total_one_star_review">0</span>)</div>
                    <div class="progress">
                      <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="one_star_progress"></div>
                    </div>
                    </p>
                  </div>
                  <div class="col-sm-4 text-center">
                    <h3 class="mt-4 mb-3">Write Review Here</h3>
                    <button type="button" name="add_review" id="add_review" class="btn btn-primary">Review</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="mt-5" id="review_content"></div>
          </div>
</body>

</html>

<div id="review_modal" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Submit Review</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h4 class="text-center mt-2 mb-4">
          <i class="fas fa-star star-light submit_star mr-1" id="submit_star_1" data-rating="1"></i>
          <i class="fas fa-star star-light submit_star mr-1" id="submit_star_2" data-rating="2"></i>
          <i class="fas fa-star star-light submit_star mr-1" id="submit_star_3" data-rating="3"></i>
          <i class="fas fa-star star-light submit_star mr-1" id="submit_star_4" data-rating="4"></i>
          <i class="fas fa-star star-light submit_star mr-1" id="submit_star_5" data-rating="5"></i>
        </h4>
        <div class="form-group">
          <input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Your Name" />
        </div>
        <div class="form-group">
          <textarea name="user_review" id="user_review" class="form-control" placeholder="Type Review Here"></textarea>
        </div>
        <div class="form-group text-center mt-4">
          <button type="button" class="btn btn-primary" id="save_review">Submit</button>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  .progress-label-left {
    float: left;
    margin-right: 0.5em;
    line-height: 1em;
  }

  .progress-label-right {
    float: right;
    margin-left: 0.3em;
    line-height: 1em;
  }

  .star-light {
    color: #e9ecef;
  }
</style> -->

    </div>

    <!-- <script src="review.js"></script> -->

    <footer>
    <div class="footer">
      <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
    </div>
    </footer>

</body>

</html>