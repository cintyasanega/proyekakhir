<?php
error_reporting(0);
include 'db.php';

$review = mysqli_query($conn, "SELECT * FROM reviews LIMIT 4" );
$r = mysqli_fetch_object($review);


// Fungsi untuk menampilkan ulasan dari database




?>

<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Detail Produk</title>
 <link rel="stylesheet" href="css/style.css">
 <link rel=" preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
 <header>
  <div class="container">
   <h1><a href="index.php">Cipta Rasa</a></h1>
   <ul>
    <li><a href="produk.php"><img src="img/icon/produk2.png" width="35px"></a></li>
    <li><a href="index.php"><img src="img/icon/index.png" width="35px" style="margin-left: 10px;"></a></li>
    <li><a href="contact.php"><img src="img/icon/contact2.png" width="35px" style="margin-left: 10px;"></a></li>
   </ul>
  </div>
 </header>

 <div class="section">
  <div class="container">
   <h3>Review</h3>
   <div class="box">
    <div class="col-2">
      <?php
      if ($r > 0) {
       while  ($row = mysqli_fetch_array($review)) {
        echo "<p><strong>Nama Pengguna:</strong> " . $row["username"] . "</p>";
        echo "<p><strong>Ulasan:</strong> <br>"  . $row["review_text"] . "</p>";
        echo "<p><strong>Peringkat:</strong> <br>";
          $rating = $row["rating"];
          for ($i = 1; $i <= 5; $i++) {
              if ($i <= $rating) {
                  echo '<img src="img/icon/bintang.png" alt="' . $i . ' bintang" style="width: 50px;">';
              } else {
                  echo '<img src="img/icon/nobintang.png" alt="0 bintang" style="width: 50px;">';
              }
          }
          echo "<hr>";
         }
        } else {
         echo "<p>Belum ada ulasan.</p>";
        }
        ?>
    </div>
   </div>
  </div>

  <footer>
   <div class="container">
    <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
   </div>
  </footer>

</body>

</html>