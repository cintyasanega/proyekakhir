<?php
session_start();
include 'db.php';
if ($_SESSION['status_login'] != true) {
     echo '<script>window.location="login.php"</script>';
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Data Kategori</title>
     <link rel="stylesheet" href="css/style.css">
     <link href="<link rel= " preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>

<body>
     <header>
          <div class="container">
               <h1><a href="dashboard.php">Rengginang Cipta Rasa</a></h1>
               <ul>
                    <li><a href="dashboard.php"><img src="img/icon/index.png" width="30px"></a></li>
                    <li><a href="profil.php"><img src="img/icon/admin.png" width="30px"></a></li>
                    <li><a href="admin-kategori.php"><img src="img/icon/datakat.png" width="30px"></a></li>
                    <li><a href="data-produk.php"><img src="img/icon/produk2.png" width="30px"></a></li>
                    <li><a href="logout.php" onclick="return confirm('Apakah yakin untuk keluar?')"><img src="img/icon/logout.png" width="30px"></a></li>
               </ul>
          </div>
     </header>

     <div class="section">
          <div class="container">
               <h3 style="font-size: 25px;">Data Kategori</h3>
               <div class="box">
                    <p><a href="tambah-kategori.php"><img src="img/icon/tambah2.png"; width="40px" style="margin-bottom: 10px;"></a></p>
                    <table border="1" cellspacing='0' class="table">
                         <thead>
                              <tr>
                                   <th width=60px style="font-size: 20px;">No</th>
                                   <th style="font-size: 20px;">Kategori</th>
                                   <th width=200px style="font-size: 20px;">Aksi</th>
                              </tr>
                         </thead>
                         <tbody>
                              <?php
                              $no = 1;
                              $kategori = mysqli_query($conn, "SELECT * FROM category_tb ORDER BY category_id DESC");
                              if (mysqli_num_rows($kategori) > 0) {
                                   while ($row = mysqli_fetch_array($kategori)) {
                              ?>
                                        <tr>
                                             <td style="text-align: center; font-size: 18px;"><?php echo $no++ ?></td>
                                             <td style="font-size: 18px;" ><?php echo $row['category_name'] ?></td>
                                             <td>
                                                  <!-- mengedit sambil mengirim id kategori tiap kategori hapus juga sama -->
                                                  <a href="edit-kategori.php?id=<?php echo $row['category_id'] ?>"><img src="img/icon/edit2.png" ; width="35px" ; style="margin: 0 5px 0 50px;"></a>
                                                  <a href="hapus.php?idk=<?php echo $row['category_id'] ?>" onclick="return confirm('Apakah yakin untuk menghapus kategori?')"><img src="img/icon/delete2.png" ; width="35px"></a>
                                             </td>
                                        </tr>
                                   <?php }
                              } else { ?>
                                   <tr>
                                        <td colspan="3">Tidak ada data</td>
                                   </tr>
                              <?php } ?>
                         </tbody>
                    </table>
               </div>
          </div>
     </div>


     <footer>
          <div class="container">
               <small>Copyright &copy 2023 - Proyek Akhir - Cintya Sanega Akmalia</small>
          </div>
     </footer>
</body>

</html>