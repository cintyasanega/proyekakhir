<?php
include 'db.php';


// Fungsi untuk menyimpan ulasan ke database
function simpan_ulasan($conn, $username, $review_text, $rating) {
    $sql = "INSERT INTO reviews (username, review_text, rating) VALUES ('$username', '$review_text', '$rating')";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Fungsi untuk menampilkan ulasan dari database
function tampilkan_ulasan($conn) {
    $sql = "SELECT * FROM reviews";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Ulasan Pengguna</h2>";
        while ($row = $result->fetch_assoc()) {
            echo "<p><strong>Nama Pengguna:</strong> " . $row["username"] . "</p>";
            echo "<p><strong>Ulasan:</strong> " . $row["review_text"] . "</p>";
            echo "<p><strong>Peringkat:</strong> " . $row["rating"] . " bintang</p>";
            echo "<hr>";
        }
    } else {
        echo "<p>Belum ada ulasan.</p>";
    }
}

// Main code
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $review_text = $_POST['review_text'];
    $rating = $_POST['rating'];

    if (simpan_ulasan($conn, $username, $review_text, $rating)) {
        echo "<p>Ulasan berhasil disimpan!</p>";
    } else {
        echo "<p>Gagal menyimpan ulasan.</p>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Deskripsi Produk</title>
</head>
<body>
    <h1>Deskripsi Produk</h1>

    <!-- Formulir untuk mengirim ulasan -->
    <h2>Tulis Ulasan Anda</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        Nama Pengguna: <input type="text" name="username" required><br>
        Ulasan: <textarea name="review_text" required></textarea><br>
        Peringkat: 
        <select name="rating">
            <option value="1">1 Bintang</option>
            <option value="2">2 Bintang</option>
            <option value="3">3 Bintang</option>
            <option value="4">4 Bintang</option>
            <option value="5">5 Bintang</option>
        </select><br>
        <input type="submit" value="Kirim Ulasan">
    </form>


</body>
</html>
